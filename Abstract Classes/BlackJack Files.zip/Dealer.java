//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  - 


//define Dealer class here
	
	
	
	
	//instance variable - Deck 





	//constructors





	//method to shuffle






	//method to deal a card





	//hit method goes here
